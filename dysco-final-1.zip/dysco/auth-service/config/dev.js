module.exports = {
    googleClientId : '1039373968404-5sqa18our9adlhrsiiu350u4ilbqj26b.apps.googleusercontent.com',
    googleClientSecret : 'HIBh8WPxgnPcBR6in3e0nCFm',
    mongoUri : 'mongodb://dysco-dev:dysco123@ds119394.mlab.com:19394/dysco-dev',
    cookieKey : 'asdasdafsdjgnsdkfnsdkfnsdkfnsdkfnsdfknsdfa',
    facebookClientId : '575794292893878',
    facebookClientSecret : 'c7c685bc41668235ff5b85240b114a35'
}