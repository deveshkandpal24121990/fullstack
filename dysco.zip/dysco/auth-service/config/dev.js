module.exports = {
    googleClientId : '1039373968404-5sqa18our9adlhrsiiu350u4ilbqj26b.apps.googleusercontent.com',
    googleClientSecret : 'HIBh8WPxgnPcBR6in3e0nCFm',
    mongoUri : 'mongodb://kandpal123:kandpal1234@ds123124.mlab.com:23124/kandpal123',
    cookieKey : 'asdasdafsdjgnsdkfnsdkfnsdkfnsdkfnsdfknsdfa',
    facebookClientId : '575794292893878',
    facebookClientSecret : 'c7c685bc41668235ff5b85240b114a35'
}