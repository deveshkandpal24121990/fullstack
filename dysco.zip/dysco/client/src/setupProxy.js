const proxy = require('http-proxy-middleware')

module.exports = function(app) {
    const target = process.env.TARGET || 'http://localhost:5000';
    console.log('target ', target)
    app.use(proxy('/auth/google', { target: target }))
    app.use(proxy('/api/current_user', { target: target }))
    app.use(proxy('/api/logout', { target: target }))

}